#include "bsp_usart.h"



void USART1_Config(void)
{
	GPIO_InitTypeDef    GPIO_InitStructure;
	USART_InitTypeDef   USART_InitStructure; 
	NVIC_InitTypeDef    NVIC_InitStructure;

	/*使能USART1和GPIOA外设时钟*/
	RCC_APB2PeriphClockCmd (RCC_APB2Periph_USART1 | RCC_APB2Periph_GPIOA, ENABLE);

	/*复位串口1水*/
	USART_DeInit (USART1);

	/*USART1_GPIO初始化设置*/
	// 将USART Tx的GPIO配置为推挽复用模式
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;     //USART1_TXD (PA.9)
	GPIO_InitStructure.GPIO_Mode= GPIO_Mode_AF_PP;      //复用推挽输出
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;   //设置引脚输出最大速率为50MHz
	GPIO_Init(GPIOA, &GPIO_InitStructure);        //调用库函数中的GPIO初始化函数，初始化USART1_TXD(PA.9)

	// 将USART Rx的GPIO配置为浮空输入模式
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;      //USART1_RXD(PA.10)
	GPIO_InitStructure.GPIO_Mode= GPIO_Mode_IN_FLOATING;      //浮空输入
	GPIO_Init(GPIOA,&GPIO_InitStructure);    //调用库函数中的GPIO初始化函数，初始化USART1_RXD(PA.10)

	/*USART1初始化设置*/
	USART_InitStructure.USART_BaudRate = Baut;     //设置波特率
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;    //8位数据格式
	USART_InitStructure.USART_StopBits = USART_StopBits_1;      //1个停止位
	USART_InitStructure.USART_Parity = USART_Parity_No;       //无奇偶校验位_奇偶校验有误差
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;      //无硬件数据流控制
	USART_InitStructure.USART_Mode = USART_Mode_Rx  | USART_Mode_Tx;  //工作模式设置为收发模式
	USART_Init(USART1, &USART_InitStructure);     //初始化串口1

	/*Usart1 NVIC配置*/
	NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=2;   //抢占优先级2
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;     //从优先级1
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;     //IRQ通道使能
	NVIC_Init(&NVIC_InitStructure);            //根据指定的参数初始化VIC寄存器
	USART_ITConfig(USART1,USART_IT_RXNE, ENABLE);     //使能串口1接收中断
	
	USART_Cmd (USART1,ENABLE);    //使能串口
	USART_ClearFlag (USART1,USART_FLAG_TC);      //清除发送完成标志
}

void UART1_SendString(char* s)
{
	while(*s)//检测字符串结束符
	{
		while(USART_GetFlagStatus(USART1, USART_FLAG_TC)==RESET);
		USART_SendData (USART1 ,*s++);//发送当前字符
	}
}



//重定向c库函数printf到串口，重定向后可使用printf函数
int fputc(int ch, FILE *f)
{
		/* 发送一个字节数据到串口 */
		USART_SendData(DEBUG_USARTx, (uint8_t) ch);
		
		/* 等待发送完毕 */
		while (USART_GetFlagStatus(DEBUG_USARTx, USART_FLAG_TXE) == RESET);		
	
		return (ch);
}

//重定向c库函数scanf到串口，重写向后可使用scanf、getchar等函数
int fgetc(FILE *f)
{
		/* 等待串口输入数据 */
		while (USART_GetFlagStatus(DEBUG_USARTx, USART_FLAG_RXNE) == RESET);

		return (int)USART_ReceiveData(DEBUG_USARTx);
}



