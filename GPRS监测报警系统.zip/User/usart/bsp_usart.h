#ifndef __BSP_USART_H
#define __BSP_USART_H

#include "string.h"
#include "misc.h"
#include "stm32f10x.h"
#include "stdio.h"

#define Buf1_Max 200    //����1���泤��


// ����1-USART1
#define  DEBUG_USARTx                   USART1

#define  Baut				115200



#define  DEBUG_USART_IRQHandler         USART1_IRQHandler



void USART1_Config(void);
void UART1_SendString(char* s);
void USART1_IRQHandler(void);

#endif /* __BSP_LED_H */

