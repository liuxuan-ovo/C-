#include "bsp_key.h"



//按键端口配置
void Key_GPIO_Config(void)
{
	/*定义一个GPIO_InitTypeDef类型的结构体*/
	GPIO_InitTypeDef  GPIO_InitStructure;
	
	/*开启LED相关的GPIO外设时钟*/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOC, ENABLE);
	
	/*选择要控制的GPIO引脚*/
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;	
	
	/*设置引脚模式为下拉输入*/	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
	
	/*调用库函数，初始化GPIO*/
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
	GPIO_InitStructure.GPIO_Mode= GPIO_Mode_IPD;
	GPIO_Init(GPIOC,&GPIO_InitStructure);
}

static void EXIT_NVIC_Config(void)
{
	/*定义一个NVIC_InitTypeDef类型的结构体*/
	NVIC_InitTypeDef  NVIC_InitStructure;
	
	/* 配置NVIC为优先级组1 */
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
	/* 配置中断源：按键1 */
	NVIC_InitStructure.NVIC_IRQChannel = EXTI0_IRQn;
	/* 配置抢占优先级 */
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	/* 配置子优先级 */
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	/* 使能中断通道 */
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	 /* 配置中断源：按键2，其他使用上面相关配置 */  
	NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn;
	NVIC_Init(&NVIC_InitStructure);
}

void EXIT_Key_Config(void)
{
	/*定义一个GPIO_InitTypeDef | EXTI_InitTypeDef类型的结构体*/
	GPIO_InitTypeDef  GPIO_InitStructure;
	EXTI_InitTypeDef	EXTI_InitStructure;
	
	/* 配置 NVIC 中断*/
	EXIT_NVIC_Config();
	
	/*开启按键GPIO口的时钟*/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOC, ENABLE);
	/* 选择按键用到的GPIO */	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
	/* 配置为下拉输入 */
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
	GPIO_InitStructure.GPIO_Mode= GPIO_Mode_IPD;
	GPIO_Init(GPIOC,&GPIO_InitStructure);
	
	//初始化EXTI
	/*--------------------------KEY1配置-----------------------------*/
	/*开启按键EXTI口的时钟*/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
	/* 选择EXTI的信号源 */
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource0);//PA0
	
	EXTI_InitStructure.EXTI_Line = EXTI_Line0;
	/* EXTI为中断模式 */
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	/* 上升沿中断 */
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;
	/* 使能中断 */
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStructure);
	
	/*--------------------------KEY2配置-----------------------------*/
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOC, GPIO_PinSource13);//PC13
	EXTI_InitStructure.EXTI_Line = EXTI_Line13;
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStructure);
}


#if 0
//按键检测部分程序
uint8_t Key_Scan(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin)
{
	if(GPIO_ReadInputDataBit(GPIOx,GPIO_Pin) == 1)
	{
		while(GPIO_ReadInputDataBit (GPIOx,GPIO_Pin) == 1);
		return 1;
	}
	else
		return 0;
}
#elif 0
//按键设置温度阈值
uint8_t Temp_Cmp_Value = 33;//温度阙值

uint8_t Key_Func ()
{

	if(Key_Scan(GPIOA, GPIO_Pin_0) == 1)
	{
		Temp_Cmp_Value++;
	}
	if(Key_Scan(GPIOC,GPIO_Pin_13) == 1)
	{
		Temp_Cmp_Value--;
	}
		return  Temp_Cmp_Value;
}

#endif
