#ifndef __BSP_KEY_H
#define __BSP_KEY_H

#include "stm32f10x.h"

void Key_GPIO_Config(void);
void EXIT_Key_Config(void);


//uint8_t Key_Scan(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin);
//uint8_t Key_Func();


#endif /* __BSP_KEY_H */

