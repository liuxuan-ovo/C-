
#include "stm32f10x.h"
#include "bsp_beep.h"
#include "bsp_led.h"
#include "bsp_key.h"
#include "bsp_usart.h"
#include "dht11.h"
#include "esp8266.h"
#include "esp8266_test.h"
#include "delay.h"


int main(void)
{
	
	
	/* ��ʼ��ϵͳ��ʱ�� */
	SysTick_Init();
	
	LED_GPIO_Config();
	BEEP_GPIO_Config();
	EXIT_Key_Config();
	//Key_GPIO_Config();
	USART1_Config();
	DHT11_Init();
	ESP8266_Init();
	
	printf ( "\r\n����GPRS��ⱨ��ϵͳ��������\r\n" );
	
	ESP8266_StaTcpClient_UnvarnishTest();
	
	dht11_Test();
	
}

/*********************************************END OF FILE**********************/
